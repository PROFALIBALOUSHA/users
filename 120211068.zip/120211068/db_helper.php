<?php
class DbHelper
{


    private $conn;
    function createDbConnection()
    {
        try {
            $this->conn = new mysqli("localhost", "root", "", "company");
        } catch (Exception $error) {
            echo $error->getMessage();

        }
    }

    function insertNewUser($name, $email)
    {
        try {
            $sql = "INSERT INTO users (name,email)VALUES ('$name','$email')";
            $result = $this->conn->query($sql);
            if ($result == true) {
                echo json_encode(
                    array(
                        "success" => true,
                        "message" => "new user has been added"
                    )
                );
            } else {
                echo json_encode(
                    array(
                        "success" => false,
                        "message" => "new user has not been added"
                    )
                );
            }

        } catch (Exception $error) {
            echo $error->getMessage();

        }
    }

    public function getAllUsers()
    {
        $sql = "SELECT * FROM `users`";
        $result = $this->conn->query($sql);
        $count = $result->num_rows;
        if ($count > 0) {
            while ($row = $result->fetch_assoc()) {
                $row["id"];
                $row["name"];
                $row["email"];
            }
        }
    }
    function getUserById($id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    function deleteUser($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM uses WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount();
    }
    function updateStudent($id, $name, $email)
    {
        $stmt = $this->conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $stmt->execute([$name, $email, $id]);
        return $stmt->rowCount();
    }
}
?>